import math
import random
import json
from basics import *
import worldeditor

WORLD = [["air" for x in range(BOARDSIZE[1])] for x in range(BOARDSIZE[0])]

logicalHeight = math.floor(BOARDSIZE[1] / 2)
height = math.floor(BOARDSIZE[1] / 3)

waterHeight = math.floor(BOARDSIZE[1] / 1.1)

mode = False

for x in range(BOARDSIZE[0]):
	# Height
	height += random.choice([-1, 0, 1])
	if height < logicalHeight: height += random.choice([0, 0, 1])
	else: height -= random.choice([0, 0, 1])
	if mode: height += random.choice([0, 0, 1])
	else: height -= random.choice([0, 0, 1])
	for i in range(height):
		WORLD[x][(BOARDSIZE[1] - 1) - i] = random.choices(["stone", "tnt"], weights=[10, 1], k=1)[0]
	# Water Height
	for i in range(height, waterHeight):
		WORLD[x][(BOARDSIZE[1] - 1) - i] = "lava"
	# Mode
	if random.random() < 0.1: mode = not mode

worldeditor.save(WORLD)
