import math
import random
import json
from basics import *
import worldeditor

WORLD = [["air" for x in range(BOARDSIZE[1])] for x in range(BOARDSIZE[0])]

def house(x, y):
	rad = 5
	for mx in range(x, x + rad):
		for my in range(y, y + rad):
			if mx >= 0 and my >= 0 and mx < BOARDSIZE[0] and my < BOARDSIZE[1]:
				if mx == x or my == y or mx == x + rad + (-1) or my == y + rad + (-1):
					WORLD[mx][my] = random.choices(["stone", "hard_stone", "lava", "air"], weights=[100, 10, 1, 1], k=1)[0]
				else:
					WORLD[mx][my] = random.choices(["air", "stone", "hard_stone", "lava", "tnt"], weights=[100, 10, 10, 1, 20], k=1)[0]

for x in range(10):
	for y in range(10):
		house(x * 4, y * 4)
for z in range(10):
	house(random.randint(0, BOARDSIZE[0] - 1), random.randint(0, BOARDSIZE[1] - 1))

for x in range(BOARDSIZE[0]):
	WORLD[x][0] = "hard_stone"
	WORLD[x][BOARDSIZE[1] - 1] = "hard_stone"
for y in range(BOARDSIZE[1]):
	WORLD[0][y] = "hard_stone"
	WORLD[BOARDSIZE[0] - 1][y] = "hard_stone"

worldeditor.save(WORLD)
