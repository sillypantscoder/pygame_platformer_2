import math
import random
import json
from basics import *
import worldeditor

WORLD = [["lava" for x in range(BOARDSIZE[1])] for x in range(BOARDSIZE[0])]

logicalHeight = math.floor(BOARDSIZE[1] / 1.5)
height = math.floor(BOARDSIZE[1] / 1.5)

for x in range(BOARDSIZE[0]):
	# Height
	height += random.choice([-1, 0, 1])
	if height < logicalHeight: height += random.choice([0, 0, 1])
	else: height -= random.choice([0, 0, 1])
	for i in range(height):
		WORLD[x][(BOARDSIZE[1] - 1) - i] = random.choices(["stone", "tnt"], weights=[10, 1], k=1)[0]

worldeditor.save(WORLD, [])
