import math
import random
import json
from basics import *
import worldeditor

WORLD = [["air" for x in range(BOARDSIZE[1])] for x in range(BOARDSIZE[0])]

def insideBoard(x, y):
	return x >= 0 and x < BOARDSIZE[0] and y >= 0 and y < BOARDSIZE[1]

def drawStructure(cx, cy, structure):
	for y in range(len(structure)):
		for x in range(len(structure[y])):
			if insideBoard(cx + x, cy + y):
				if structure[y][x] == "=":
					WORLD[cx + x][cy + y] = "stone"

def addApartmentFloor(cx, cy):
	structure = ["=====", "  =  ", "=   ="]
	drawStructure(cx, cy, structure)

def addApartmentSection(cx, cy):
	structure = [random.choice(["= = =", "== ==", "=== =", "= ==="]), "=   ="]
	drawStructure(cx, cy, structure)

def addApartmentRoof(cx, cy):
	structure = ["=   =", "====="]
	drawStructure(cx, cy, structure)

def addAngledRoof(cx, cy):
	structure = ["=   =", " = = ", "  =  "]
	drawStructure(cx, cy, structure)

def addChimneyRoof(cx, cy):
	structure = ["=   =", "=  ==", "= ===", "=  ==", "==  =", "=== =", "==  =", "=  ==", "= ===", "=   =", "=  = ", "= =  ", "=   =", "====="]
	drawStructure(cx, cy, structure)

def addApartment(cx):
	height = random.randint(BOARDSIZE[1] / 3, BOARDSIZE[1] / 1.5)
	addApartmentFloor(cx, 0)
	for y in range(3, height, 2):
		addApartmentSection(cx, y)
	if random.random() > 0.3:
		addApartmentRoof(cx, height)
	elif random.random() < 0.5:
		addChimneyRoof(cx, height)
	else:
		addAngledRoof(cx, height)

for x in range(0, BOARDSIZE[0], 5):
	addApartment(x)

WORLD = [[WORLD[x][(BOARDSIZE[1] - 1) - y] for y in range(BOARDSIZE[0])] for x in range(BOARDSIZE[1])]
worldeditor.save(WORLD, [])
