import math
import random
import json
from basics import *
import worldeditor

WORLD = [["air" for x in range(BOARDSIZE[1])] for x in range(BOARDSIZE[0])]

def insideBoard(x, y):
	return x >= 0 and x < BOARDSIZE[0] and y >= 0 and y < BOARDSIZE[1]

def addClump(cx, cy):
	WORLD[cx][cy] = "stone"
	width = 5
	height = 10
	for x in range(-width, width):
		for y in range(height):
			if abs(x * 10) + y <= width * 5 or random.randint(0, 13) == 0:
				if insideBoard(cx + x, cy + y):
					if y < 1:
						WORLD[cx + x][cy + y] = random.choices(["sand", "stone"], weights=[8, 9], k=1)[0]
					else:
						WORLD[cx + x][cy + y] = random.choices(["sand", "stone"], weights=[1, 40], k=1)[0]
			elif random.randint(0, 100) == 0:
				if insideBoard(cx + x, cy + y): WORLD[cx + x][cy + y] = "water"

for x in range(BOARDSIZE[0]):
	for y in range(BOARDSIZE[1]):
		if random.randint(0, 125) == 0:
			addClump(x, y)

worldeditor.save(WORLD, [])
