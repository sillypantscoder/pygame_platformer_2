import random
from basics import *
import worldeditor
import os

WORLD = [["air" for x in range(BOARDSIZE[1])] for x in range(BOARDSIZE[0])]

def island(x, y):
	rad = random.randint(2, 5)
	for mx in range(x - rad, x + rad):
		for my in range(y, y + rad):
			if (my - y) < rad - (mx - x) and (my - y) < (mx - x) + rad:
				if mx >= 0 and my >= 0 and mx < BOARDSIZE[0] and my < BOARDSIZE[1]:
					WORLD[mx][my] = random.choices(["stone", "dirt"], weights=[2, 1], k=1)[0]
	prev_tree = False
	for mx in range(x - rad, x + rad):
		# TREES
		treefreq = 0.1
		if (not prev_tree) and random.random() < treefreq:
			# VINES
			treeHeight = y - random.choice([2, 3, 3, 3, 4, 4])
			# TRUNK
			for y in range(treeHeight, y):
				WORLD[x][y] = "wood"
			# LEAVES
			leafrad = 1
			for xx in range(x - leafrad, x + leafrad + 1):
				for y in range(treeHeight - 3, treeHeight):
					try:
						WORLD[xx][y] = "leaves"
					except: print("(err drawing leaves)", end="")

island(2, 8)
for x in range(5):
	island(random.randint(0, BOARDSIZE[0] - 1), random.randint(0, BOARDSIZE[1] - 1))

worldeditor.save(WORLD, [])
