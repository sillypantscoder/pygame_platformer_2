import math
import random
from basics import *
import worldeditor

WORLD = [["air" for x in range(BOARDSIZE[1])] for x in range(BOARDSIZE[0])]

logicalHeight = math.floor(BOARDSIZE[1] / 2)
height = math.floor(BOARDSIZE[1] / 2)

logicalBedrockHeight = math.floor(BOARDSIZE[1] * (5/6))
bedrockHeight = math.floor(BOARDSIZE[1] * (5/6))

waterHeight = math.floor(BOARDSIZE[1] / 1.7)

prev_tree = True
mode = random.choice(["normal", "forest", "jungle", "desert"])
if mode == "jungle": waterHeight = math.floor(BOARDSIZE[1] / 1.9)

if mode in ["normal", "forest", "jungle"]:
	for x in range(BOARDSIZE[0]):
		# Height
		height += random.choice([-1, 0, 1])
		if height < logicalHeight: height += random.choice([0, 0, 1])
		else: height -= random.choice([0, 0, 1])
		for i in range(height, BOARDSIZE[1]):
			if i == height: WORLD[x][i] = "dirt"
			else: WORLD[x][i] = random.choices(["stone", "dirt"], weights=[5, 1], k=1)[0]
		# Bedrock Height
		bedrockHeight += random.choice([-1, 0, 1])
		if bedrockHeight < logicalBedrockHeight: bedrockHeight += random.choice([0, 0, 1])
		else: bedrockHeight -= random.choice([0, 0, 1])
		for i in range(bedrockHeight, BOARDSIZE[1]):
			WORLD[x][i] = "hard_stone"
		# Water Height
		hasWater = 0
		for i in range(waterHeight, height):
			WORLD[x][i] = "water"
			hasWater += 1
		# Coral
		if mode == "jungle" and hasWater >= 3: WORLD[x][height] = "coral"
		# Tree
		treefreq = 0.1
		if mode in ["forest", "jungle"]: treefreq += 0.6
		if (mode in ["forest", "jungle"] or not prev_tree) and (not hasWater) and random.random() < treefreq:
			# VINES
			treeHeight = height - random.choice([2, 3, 3, 3, 4, 4])
			if mode == "jungle": treeHeight -= random.choice([2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 6])
			if mode == "jungle":
				for y in range(treeHeight, random.randint(treeHeight + 2, height)):
					try:
						if WORLD[x - leafrad][y] == "air": WORLD[x - leafrad][y] = "vines"
					except: print("(err drawing vines)", end="")
					try:
						if WORLD[x - leafrad][y] == "air": WORLD[x + leafrad][y] = "vines"
					except: print("(err drawing vines)", end="")
			# TRUNK
			for y in range(treeHeight, height):
				WORLD[x][y] = "wood"
			# LEAVES
			leafrad = 1
			if mode == "jungle": leafrad = 2
			for xx in range(x - leafrad, x + leafrad + 1):
				for y in range(treeHeight - 3, treeHeight):
					try:
						WORLD[xx][y] = "leaves"
					except: print("(err drawing leaves)", end="")
			prev_tree = True
		else:
			# no tree this time
			prev_tree = False
elif mode == "desert":
	for x in range(BOARDSIZE[0]):
		# Height
		height += random.choice([-1, 0, 1])
		if height < logicalHeight: height += random.choice([0, 0, 1])
		else: height -= random.choice([0, 0, 1])
		for i in range(height, BOARDSIZE[1]):
			WORLD[x][i] = random.choices(["sand"], weights=[1], k=1)[0]
		# Water Height
		hasWater = False
		for i in range(waterHeight, height):
			WORLD[x][i] = "water"
			hasWater = True
		# CACTUSES
		treefreq = 0.2
		if (random.random() < treefreq or not prev_tree) and (not hasWater) and random.random() < treefreq:
			treeHeight = height - random.choice([1, 2, 2, 2, 3, 3])
			for y in range(treeHeight, height):
				WORLD[x][y] = "cactus"
			prev_tree = True
		else:
			# no cactus this time
			prev_tree = False

print()

worldeditor.save(WORLD, [])
