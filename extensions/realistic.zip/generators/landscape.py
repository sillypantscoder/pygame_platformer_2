import math
import random
import json
from basics import *

WORLD = [["air" for x in range(BOARDSIZE[1])] for x in range(BOARDSIZE[0])]

logicalHeight = math.floor(BOARDSIZE[1] / 2)
height = math.floor(BOARDSIZE[1] / 2)

logicalBedrockHeight = math.floor(BOARDSIZE[1] * (5/6))
bedrockHeight = math.floor(BOARDSIZE[1] * (5/6))

waterHeight = math.floor(BOARDSIZE[1] / 1.7)

prev_tree = True
mode = random.choice(["normal", "forest"])

for x in range(BOARDSIZE[0]):
	# Height
	height += random.choice([-1, 0, 1])
	if height < logicalHeight: height += random.choice([0, 0, 1])
	else: height -= random.choice([0, 0, 1])
	for i in range(height, BOARDSIZE[1]):
		WORLD[x][i] = random.choices(["stone"], weights=[1], k=1)[0]
	# Bedrock Height
	bedrockHeight += random.choice([-1, 0, 1])
	if bedrockHeight < logicalBedrockHeight: bedrockHeight += random.choice([0, 0, 1])
	else: bedrockHeight -= random.choice([0, 0, 1])
	for i in range(bedrockHeight, BOARDSIZE[1]):
		WORLD[x][i] = "hard_stone"
	# Water Height
	hasWater = False
	for i in range(waterHeight, height):
		WORLD[x][i] = "water"
		hasWater = True
	# Tree
	treefreq = 0.1
	if mode in ["forest", "jungle"]: treefreq += 0.6
	if (mode in ["forest", "jungle"] or not prev_tree) and (not hasWater) and random.random() < treefreq:
		# VINES & JUNGLE MODE-- coming soon!
		"""
		if mode == "jungle": treeHeight -= random.choice([3, 3, 4, 4, 4, 5])
		if mode == "jungle":
			for y in range(treeHeight, treeHeight + 3):
				try:
					WORLD[x - leafrad][y] = "vines"
				except: print("(err drawing vines)", end="")
				try:
					WORLD[x + leafrad][y] = "vines"
				except: print("(err drawing vines)", end="")"""
		# TRUNK
		treeHeight = height - random.choice([2, 3, 3, 3, 4, 4])
		for y in range(treeHeight, height):
			WORLD[x][y] = "wood"
		# LEAVES
		leafrad = 1
		#if mode == "jungle": leafrad = 2
		for xx in range(x - leafrad, x + leafrad + 1):
			for y in range(treeHeight - 3, treeHeight):
				try:
					WORLD[xx][y] = "leaves"
				except: print("(err drawing leaves)", end="")
		prev_tree = True
	else:
		# no tree this time
		prev_tree = False

print()

f = open("world.json", "w")
f.write(json.dumps(WORLD).replace("], [", "],\n ["))
f.close()
