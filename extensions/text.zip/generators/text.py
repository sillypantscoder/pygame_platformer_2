import pygame
import tkinter as tk
from tkinter import simpledialog
from tkinter import messagebox
from basics import *
import json

def askstring(msg):
	TKROOT = tk.Tk()
	TKROOT.withdraw()
	d = simpledialog.askstring("Text Generator", msg)
	TKROOT.destroy()
	return d

pygame.font.init()

font = pygame.font.SysFont(pygame.font.get_default_font(), 20)
text = askstring("Enter the text message")

rendered = font.render(text, True, (0, 0, 0))

WORLD = [["air" for x in range(BOARDSIZE[1])] for y in range(BOARDSIZE[0])]

r_width = rendered.get_width()
r_height = rendered.get_height()

for x in range(r_width):
	for y in range(r_height):
		try:
			pixel = rendered.get_at((x, y))[3]
			if pixel > 150:
				WORLD[x][y] = "pict_block_full"
			elif pixel > 50:
				WORLD[x][y] = "pict_block_half"
		except:
			print("E", end="")

print()

f = open("world.json", "w")
f.write(json.dumps(WORLD).replace("], [", "],\n ["))
f.close()
