import pygame
import dialog
from basics import *
import json

pygame.font.init()

font = pygame.font.SysFont(dialog.prompt("Enter font to use", pygame.font.get_default_font()), 20)
text = dialog.prompt("Enter the text message", "Hi there")

rendered = font.render(text, True, (0, 0, 0))

WORLD = [["air" for x in range(BOARDSIZE[1])] for y in range(BOARDSIZE[0])]

r_width = rendered.get_width()
r_height = rendered.get_height()

for x in range(r_width):
	for y in range(r_height):
		try:
			pixel = rendered.get_at((x, y))[3]
			if pixel > 150:
				WORLD[x][y] = "pict_block_full"
			elif pixel > 50:
				WORLD[x][y] = "pict_block_half"
		except:
			print("E", end="")

print()

f = open("world.json", "w")
f.write(json.dumps(WORLD).replace("], [", "],\n ["))
f.close()
