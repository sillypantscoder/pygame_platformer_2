import pygame
import tkinter as tk
from tkinter import simpledialog
from tkinter import messagebox
from basics import *
import json
from math import floor
import worldeditor

def askstring(msg):
	TKROOT = tk.Tk()
	TKROOT.withdraw()
	d = simpledialog.askstring("Text Generator", msg)
	TKROOT.destroy()
	return d

pygame.font.init()

font = pygame.font.SysFont(pygame.font.get_default_font(), 20)
text = askstring("Enter the text message")

text = font.render(text, True, (0, 0, 0))
rendered = pygame.Surface((text.get_width(), text.get_height()))
rendered.fill((255, 255, 255))
rendered.blit(text, (0, 0))

WORLD = [["air" for x in range(BOARDSIZE[1])] for y in range(BOARDSIZE[0])]

r_width = rendered.get_width()
r_height = rendered.get_height()

for x in range(r_width):
	for y in range(r_height):
		try:
			pixel = rendered.get_at((x, y))
			#alpha = pixel[3] / 255
			#pixel = (pixel[0] * alpha, pixel[1] * alpha, pixel[2] * alpha)
			WORLD[x][y] = f"block_{floor(pixel[0] / 4.0)}_{floor(pixel[1] / 4.0)}_{floor(pixel[2] / 4.0)}"
		except Exception as e:
			print("E", end="")

print()

worldeditor.save(WORLD)
