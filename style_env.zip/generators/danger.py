import random
import json
from basics import *
import worldeditor

WORLD = []

for x in range(BOARDSIZE[0]):
	WORLD.append([])
	for y in range(BOARDSIZE[1]):
		if y > 10: WORLD[x].append("stone")
		else:
			if x % 2 == 0 or y % 2 == 0: WORLD[x].append("tnt")
			else: WORLD[x].append("sand")

WORLD[2][0] = "air"
WORLD[2][1] = "hard_stone"

worldeditor.save(WORLD, [["allay", 0, 0]])
