import random
import json
from basics import *
import zipHelpers

BLOCKS = json.loads(zipHelpers.extract_zip("style_env.zip").items["blocks.json"].decode("UTF-8"))


WORLD = []

for x in range(BOARDSIZE[0]):
	WORLD.append([])
	for y in range(BOARDSIZE[1]):
		b = random.choice(list(BLOCKS.keys()))
		WORLD[x].append(b)

f = open("world.json", "w")
f.write(json.dumps(WORLD).replace("], [", "],\n ["))
f.close()
