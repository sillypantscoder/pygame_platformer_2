import random
import json
from basics import *
import zipHelpers
import worldeditor

BLOCKS = json.loads(zipHelpers.extract_zip("style_env.zip").items["blocks.json"].decode("UTF-8"))


WORLD = []
l = [x for x in list(BLOCKS.keys()) if BLOCKS[x]["collision"] != "spawner"]

for x in range(BOARDSIZE[0]):
	WORLD.append([])
	for y in range(BOARDSIZE[1]):
		b = random.choice(l)
		WORLD[x].append(b)

worldeditor.save(WORLD, [])
