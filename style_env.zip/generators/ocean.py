import math
import random
import json
from basics import *
import worldeditor

WORLD = [["air" for x in range(BOARDSIZE[1])] for x in range(BOARDSIZE[0])]

logicalHeight = math.floor(BOARDSIZE[1] / 2)
height = math.floor(BOARDSIZE[1] / 3)

logicalBedrockHeight = math.floor(BOARDSIZE[1] / 6)
bedrockHeight = math.floor(BOARDSIZE[1] / 6)

waterHeight = math.floor(BOARDSIZE[1] / 1.8)

mode = False

for x in range(BOARDSIZE[0]):
	# Height
	height += random.choice([-1, 0, 1])
	if height < logicalHeight: height += random.choice([0, 0, 1])
	else: height -= random.choice([0, 0, 1])
	if mode: height += random.choice([0, 0, 1])
	else: height -= random.choice([0, 0, 1])
	for i in range(height):
		WORLD[x][(BOARDSIZE[1] - 1) - i] = random.choices(["stone", "tnt"], weights=[10, 1], k=1)[0]
	# Bedrock Height
	bedrockHeight += random.choice([-1, 0, 1])
	if bedrockHeight < logicalBedrockHeight: bedrockHeight += random.choice([0, 0, 1])
	else: bedrockHeight -= random.choice([0, 0, 1])
	for i in range(bedrockHeight):
		WORLD[x][(BOARDSIZE[1] - 1) - i] = "hard_stone"
	if height < logicalBedrockHeight:
		try: WORLD[x][(BOARDSIZE[1] - 1) - bedrockHeight] = "spawner"
		except: print("(err placing spawner)")
	# Water Height
	for i in range(height, waterHeight):
		try: WORLD[x][(BOARDSIZE[1] - 1) - i] = "water"
		except: print("(err placing water)")
	# Mode
	if random.random() < 0.1: mode = not mode

worldeditor.save(WORLD, [])
