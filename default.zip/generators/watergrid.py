import random
import json
from basics import *

WORLD = [["air" for x in range(BOARDSIZE[0])] for y in range(BOARDSIZE[1])]

currentx = 0
currenty = 0
for x in range(BOARDSIZE[0]):
	currenty += 1
	if currenty % 4 == 1: currentx = 0
	else: currentx = 1
	for y in range(BOARDSIZE[1]):
		currentx += 1
		try:
			WORLD[currentx][currenty] = random.choices(["stone", "tnt"], weights=[10, 1], k=1)[0]
		except: WORLD;
		currentx += 1
	currenty += 1

WORLD[2][0] = "air"
WORLD[2][1] = "hard_stone"
WORLD[round(BOARDSIZE[0] / 2)][0] = "water"

f = open("world.json", "w")
f.write(json.dumps(WORLD).replace("], [", "],\n ["))
f.close()
