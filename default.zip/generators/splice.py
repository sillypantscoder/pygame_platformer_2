import random
import json
from basics import *
import zipHelpers
import os
import worldeditor

rawItems = zipHelpers.extract_zip("style_env.zip").items
generators = []
for filename in rawItems:
	if filename.startswith("generators/"):
		if filename != "generators/splice.py":
			generators.append(rawItems[filename])

WORLD = [["air" for y in range(BOARDSIZE[1])] for x in range(BOARDSIZE[0])]

random.shuffle(generators)

entities = []
playerpos = []
items = {}

def gainitem(item):
	if not item in items:
		items[item] = 0
	items[item] += 1

begin = True
for gen in generators:
	f = open("splice_generator.py", "wb")
	f.write(gen)
	f.close()
	os.system("python3 splice_generator.py")
	os.system("rm splice_generator.py")
	generated_world, e, p, i = worldeditor.load()
	# WORLD
	pos = (random.randint(0, BOARDSIZE[0] - 1), random.randint(0, BOARDSIZE[1] - 1))
	if begin: pos = (0, 0)
	begin = False
	size = (random.randint(pos[0], BOARDSIZE[0] - 1), random.randint(pos[1], BOARDSIZE[1] - 1))
	for x in range(pos[0], size[0]):
		for y in range(pos[1], size[1]):
			try:
				WORLD[x][y] = generated_world[x][y]
			except:
				print("off board:", x, y, "generator:", gen)
	# ENTITIES
	for n in e:
		entities.append(n)
	playerpos.append(p)
	for n in i:
		gainitem(n)

worldeditor.save(WORLD, entities, random.choice(playerpos), items)
